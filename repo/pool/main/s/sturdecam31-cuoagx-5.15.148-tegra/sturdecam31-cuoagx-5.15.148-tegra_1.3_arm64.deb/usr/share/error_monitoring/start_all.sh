#!/bin/bash

/home/nvidia/hm_service/err_log/log_monitor.sh &
/home/nvidia/hm_service/err_log/cam_status.sh &
/home/nvidia/hm_service/err_log/err_pop.sh &

wait
