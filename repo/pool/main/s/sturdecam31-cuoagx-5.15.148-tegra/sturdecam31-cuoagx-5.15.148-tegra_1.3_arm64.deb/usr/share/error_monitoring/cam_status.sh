#!/bin/bash

###########################################################
# CAMERA / SERDES / ISP ERROR MONITOR
###########################################################

echo "=================================================="
echo "Starting Camera + SerDes + ISP Monitoring"
echo "=================================================="

###########################################################
# SYSFS ENTRY
###########################################################

SYSFS_DIR="/tmp/cam_status"

mkdir -p "${SYSFS_DIR}"

ERROR_FILE="${SYSFS_DIR}/cam_error_status"

touch "${ERROR_FILE}"

###########################################################
# FUNCTION TO PUSH ERROR TO SYSFS
###########################################################

push_error()
{
    MESSAGE="$1"

    CURRENT_TIME=$(date +"%Y-%m-%d %H:%M:%S")

    #######################################################
    # WRITE TO SYSFS ENTRY
    #######################################################

    echo "" > "${ERROR_FILE}"

    echo "======================================" >> "${ERROR_FILE}"
    echo "TIME : ${CURRENT_TIME}" >> "${ERROR_FILE}"
    echo "${MESSAGE}" >> "${ERROR_FILE}"
    echo "======================================" >> "${ERROR_FILE}"

    #######################################################
    # TERMINAL PRINT
    #######################################################

    echo ""
    echo "======================================"
    echo "${MESSAGE}"
    echo "======================================"
    echo ""
}

###########################################################
# START DMESG MONITORING
###########################################################

/usr/bin/dmesg -w | while read -r LINE
do

    #######################################################
    # CASE 1 : CAMERA DISCONNECTED
    #######################################################

    #######################################################
    # Error Causing Camera
    #######################################################

    if echo "${LINE}" | grep -qi "Error Causing Camera"
    then
        push_error "CAMERA DISCONNECTED : ${LINE}"
    fi

    #######################################################
    # Facing streaming issue
    #######################################################

    if echo "${LINE}" | grep -qi "Facing streaming issue"
    then
        push_error "STREAMING ISSUE : ${LINE}"
    fi

    #######################################################
    # Deserializer Chip is present
    #######################################################

    if echo "${LINE}" | grep -qi "Deserializer Chip is present"
    then
        push_error "DESERIALIZER PRESENT : ${LINE}"
    fi

    #######################################################
    # GMSL Link lock not detected
    #######################################################

    if echo "${LINE}" | grep -qi "GMSL Link lock not detected"
    then
        push_error "${LINE} | check power/cable connection of serializer"
    fi

    #######################################################
    # UNCORR_ERR
    #######################################################

    if echo "${LINE}" | grep -qi "uncorr_err"
    then
        push_error "UNCORR_ERR_OCCURRED : ${LINE}"
    fi

    #######################################################
    # CASE 2 : DESERIALIZER DISCONNECTED
    #######################################################

    #######################################################
    # Deserializer not detected
    #######################################################

    if echo "${LINE}" | grep -qi "Deserializer not detected"
    then
        push_error "DESERIALIZER DISCONNECTED : ${LINE}"
    fi

    #######################################################
    # CASE 3 : ISP / SENSOR ERROR HANDLER
    #######################################################

    #######################################################
    # Error in ISP/Sensor Chip ID
    #######################################################

    if echo "${LINE}" | grep -qi "Error in ISP/Sensor Chip ID"
    then
        push_error "ISP/SENSOR CHIP ID ERROR : ${LINE}"
    fi

    #######################################################
    # ISP/Sensor standby mode
    #######################################################

    if echo "${LINE}" | grep -qi "ISP/Sensor is in standby mode"
    then
        push_error "ISP/SENSOR STANDBY MODE : ${LINE}"
    fi

    #######################################################
    # Error in ISP, Need to reset
    #######################################################

    if echo "${LINE}" | grep -qi "Error in ISP, Need to reset"
    then
        push_error "ISP RESET REQUIRED : ${LINE}"
    fi

    #######################################################
    # ISP frame count
    #######################################################

    if echo "${LINE}" | grep -qi "ISP frame count"
    then
        push_error "ISP FRAME COUNT : ${LINE}"
    fi

    #######################################################
    # ISP Outputs the Frames Properly
    #######################################################

    if echo "${LINE}" | grep -qi "ISP Outputs the Frames Properly"
    then
        push_error "ISP OUTPUT NORMAL : ${LINE}"
    fi

    #######################################################
    # ISP frame count read Failed
    #######################################################

    if echo "${LINE}" | grep -qi "ISP frame count read Failed"
    then
        push_error "ISP FRAME COUNT READ FAILED : ${LINE}"
    fi

done
