#!/bin/bash

###################################################
# DISPLAY EXPORTS FOR DESKTOP POPUPS
###################################################

export DISPLAY=:0

export XAUTHORITY=/home/nvidia/.Xauthority

###################################################
# LOG STORAGE CONFIGURATION
###################################################

LOG_DIR="/home/nvidia/hm_service/system_logs"

mkdir -p "${LOG_DIR}"

BOOT_TIME=$(date +"%Y%m%d_%H%M%S")

DMESG_LOG="${LOG_DIR}/dmesg_${BOOT_TIME}.txt"

JOURNAL_LOG="${LOG_DIR}/journalctl_${BOOT_TIME}.txt"

touch "${DMESG_LOG}"

touch "${JOURNAL_LOG}"

echo "=================================="
echo "Starting Persistent Log Monitoring"
echo "Boot Time: ${BOOT_TIME}"
echo "=================================="

###################################################
# CUSTOMER CONFIG
###################################################

SO_NUMBER="SO12349"

DEVICE_ID=$(hostname)

BACKEND_URL="http://my-logs.duckdns.org:8000"

###################################################
# START LIVE LOGGING
###################################################

echo "Starting dmesg monitoring..."

/usr/bin/dmesg -w >> "${DMESG_LOG}" &

echo "Starting journalctl monitoring..."

/usr/bin/journalctl -f >> "${JOURNAL_LOG}" &


###################################################
# FUNCTION TO UPLOAD FILE
###################################################

upload_file()
{
    FILE_PATH="$1"

    FILE_NAME=$(basename "${FILE_PATH}")

    echo ""
    echo "=================================="
    echo "Processing File: ${FILE_NAME}"
    echo "=================================="

    ###################################################
    # REQUEST PRESIGNED URL
    ###################################################

    echo "Requesting upload URL..."

    RESPONSE=$(curl -s -X POST ${BACKEND_URL}/get-upload-url \
    -H "Content-Type: application/json" \
    -d "{
        \"so_number\":\"${SO_NUMBER}\",
        \"device_id\":\"${DEVICE_ID}\",
        \"filename\":\"${FILE_NAME}\"
    }")

    echo ""
    echo "Backend Response:"
    echo "${RESPONSE}"
    echo ""

    ###################################################
    # VALIDATE RESPONSE
    ###################################################

    if [ -z "${RESPONSE}" ]; then

        echo "ERROR: Empty backend response"

        return

    fi

    ###################################################
    # EXTRACT UPLOAD URL
    ###################################################

    UPLOAD_URL=$(echo "${RESPONSE}" | \
    /usr/bin/python3 -c "import sys,json; print(json.load(sys.stdin)['upload_url'])")

    ###################################################
    # VALIDATE URL
    ###################################################

    if [ -z "${UPLOAD_URL}" ]; then

        echo "ERROR: Upload URL extraction failed"

        return

    fi

    echo "Upload URL received successfully"

    ###################################################
    # UPLOAD FILE TO AWS S3
    ###################################################

    echo ""
    echo "Uploading ${FILE_NAME} to AWS S3..."

    /usr/bin/curl -v -X PUT -T "${FILE_PATH}" "${UPLOAD_URL}"

    ###################################################
    # FINAL STATUS
    ###################################################

    echo ""
    echo "${FILE_NAME} upload completed."
    echo ""
}

###################################################
# MAIN UPLOAD LOOP
###################################################

while true
do

    echo ""
    echo "=================================="
    echo "Upload Cycle Started: $(date)"
    echo "=================================="

    ###################################################
    # UPLOAD DMESG LOG
    ###################################################

    upload_file "${DMESG_LOG}"

    ###################################################
    # UPLOAD JOURNALCTL LOG
    ###################################################

    upload_file "${JOURNAL_LOG}"

    ###################################################
    # FLUSH FILESYSTEM BUFFERS
    ###################################################

    sync

    ###################################################
    # WAIT BEFORE NEXT UPLOAD
    ###################################################

    echo ""
    echo "Sleeping for 300 seconds..."
    echo ""

    sleep 300

done
