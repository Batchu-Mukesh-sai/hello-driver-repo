#!/bin/bash

###########################################################
# CAMERA / DESERIALIZER / UNCORR_ERR POPUP MONITOR
###########################################################

echo "=================================================="
echo "Starting Camera Popup Monitoring"
echo "=================================================="

###########################################################
# VARIABLES
###########################################################

STREAM_ISSUE_FOUND=0
DESER_PRESENT_FOUND=0
NOTIFICATION_FILE="/home/nvidia/hm_service/notifications.log"
CAM_NUM=""

###########################################################
# POPUP FUNCTION
###########################################################

show_popup()
{
    MESSAGE="$1"

    echo ""
    echo "======================================"
    echo "${MESSAGE}"
    echo "======================================"
    echo ""

    ###################################################
    # DETECT ACTIVE USER
    ###################################################

    ACTIVE_USER=$(who | head -1 | awk '{print $1}')

    ###################################################
    # DETECT USER ID
    ###################################################

    USER_ID=$(id -u "${ACTIVE_USER}")

    ###################################################
    # EXPORT DISPLAY
    ###################################################

    export DISPLAY=:0

    ###################################################
    # EXPORT DBUS
    ###################################################

    export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${USER_ID}/bus"

    ###################################################
    # SEND POPUP
    ###################################################

    ###################################################
	# STORE NOTIFICATION
	###################################################

	CURRENT_TIME=$(date +"%Y-%m-%d %H:%M:%S")

	echo "[${CURRENT_TIME}] ${MESSAGE}" >> \
	"${NOTIFICATION_FILE}"

	###################################################
	# KEEP ONLY LAST 20
	###################################################

	tail -n 20 "${NOTIFICATION_FILE}" > \
	"${NOTIFICATION_FILE}.tmp"

	mv "${NOTIFICATION_FILE}.tmp" \
	"${NOTIFICATION_FILE}"

    sudo -u "${ACTIVE_USER}" \
    /usr/bin/notify-send \
    -u critical \
    -t 500 \
    "ECON ALERT" \
    "${MESSAGE}"
}

###########################################################
# START DMESG MONITORING
###########################################################

/usr/bin/dmesg -w | while read -r LINE
do

    #######################################################
    # CASE 1 : DESERIALIZER DISCONNECTED
    #######################################################

    if echo "${LINE}" | grep -q "Deserializer not detected"
    then
        show_popup "DESERIALIZER DISCONNECTED"
    fi

    #######################################################
    # CASE 2 : STREAMING ISSUE DETECTED
    #######################################################

    if echo "${LINE}" | grep -q "Facing streaming issue in CAM"
    then

        ###################################################
        # EXTRACT CAMERA NUMBER
        ###################################################

        CAM_NUM=$(echo "${LINE}" | grep -o "CAM [0-9]*" | awk '{print $2}')

        STREAM_ISSUE_FOUND=1

        continue
    fi

    #######################################################
    # CHECK DESERIALIZER PRESENT
    #######################################################

    if [ "${STREAM_ISSUE_FOUND}" -eq 1 ]
    then

        if echo "${LINE}" | grep -q "Deserializer Chip is present"
        then
            DESER_PRESENT_FOUND=1
            continue
        fi
    fi

    #######################################################
    # CHECK GMSL LINK FAILURE
    #######################################################

    if [ "${STREAM_ISSUE_FOUND}" -eq 1 ] && \
       [ "${DESER_PRESENT_FOUND}" -eq 1 ]
    then

        if echo "${LINE}" | grep -q "GMSL Link lock not detected"
        then

            ###################################################
            # POPUP CAMERA DISCONNECTED
            ###################################################

            show_popup "CAM ${CAM_NUM} DISCONNECTED"

	    update_camera_state \
		"${CAM_NUM}" \
		"DISCONNECTED" \
		"${CAM_NUM}-0043"

            ###################################################
            # RESET STATE
            ###################################################

            STREAM_ISSUE_FOUND=0
            DESER_PRESENT_FOUND=0
        fi
    fi

    #######################################################
    # CASE 3 : CAMERA RECONNECTED
    #######################################################

    if echo "${LINE}" | grep -q "ISP Outputs the Frames Properly"
    then

        ###################################################
        # POPUP CAMERA RECONNECTED
        ###################################################

        if [ ! -z "${CAM_NUM}" ]
        then
            show_popup "CAM ${CAM_NUM} RECONNECTED"
        update_camera_state \
		"${CAM_NUM}" \
		"CONNECTED" \
		"${CAM_NUM}-0043"
    	else
            show_popup "CAMERA RECONNECTED"
        fi

        ###################################################
        # RESET STATE
        ###################################################

        STREAM_ISSUE_FOUND=0
        DESER_PRESENT_FOUND=0
        CAM_NUM=""
    fi


done
